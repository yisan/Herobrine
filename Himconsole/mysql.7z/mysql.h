// Copyright 2019 SMS
// License(MIT)
// Author: ShenMian
// MySQL

class Mysql
{
public:
	Mysql();
	~Mysql();

	bool connect();
	bool query(string sql);
	bool option(int optId);

private:
	MYSQL mysql;
};
